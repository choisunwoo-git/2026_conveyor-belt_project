import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import serial
import math

def rad_to_deg(rad: float) -> float:
    return rad * 180.0 / math.pi

def clamp(x, lo, hi):
    return lo if x < lo else hi if x > hi else x

class JointToUart(Node):
    def __init__(self):
        super().__init__('joint_to_uart')

        port = self.declare_parameter('port', '/dev/ttyUSB0').value
        baud = int(self.declare_parameter('baud', 115200).value)

        self.ser = serial.Serial(port, baudrate=baud, timeout=0.01)
        self.get_logger().info(f"UART open: {port} @ {baud}")

        self.sub = self.create_subscription(JointState, '/joint_states', self.cb, 10)

        # 6축 순서
        self.joint_order = ['joint1','joint2','joint3','joint4','joint5','joint6']

        # 각 조인트 라디안 범위를 "서보 0~180도"로 맵핑하기 위한 범위(URDF limit과 맞춤)
        # joint1,4,6: -pi ~ +pi
        # joint2,3: -2.0 ~ +2.0
        # joint5: -2.6 ~ +2.6
        self.rad_min = [-math.pi, -2.0, -2.0, -math.pi, -2.6, -math.pi]
        self.rad_max = [ math.pi,  2.0,  2.0,  math.pi,  2.6,  math.pi]

    def map_rad_to_servo_deg(self, rad, rmin, rmax):
        # 범위 밖이면 clamp
        rad = clamp(rad, rmin, rmax)
        # 0~1 정규화
        t = (rad - rmin) / (rmax - rmin) if (rmax - rmin) != 0 else 0.0
        # 0~180으로 매핑
        deg = t * 180.0
        return int(round(clamp(deg, 0.0, 180.0)))

    def cb(self, msg: JointState):
        name_to_pos = {n: p for n, p in zip(msg.name, msg.position)}
        if not all(j in name_to_pos for j in self.joint_order):
            return

        out = []
        for i, jn in enumerate(self.joint_order):
            rad = name_to_pos[jn]
            out.append(self.map_rad_to_servo_deg(rad, self.rad_min[i], self.rad_max[i]))

        # FPGA 수신 포맷(6개 고정):
        # A:090,090,090,090,090,090\n
        line = f"A:{out[0]:03d},{out[1]:03d},{out[2]:03d},{out[3]:03d},{out[4]:03d},{out[5]:03d}\n"
        self.ser.write(line.encode('ascii'))

def main():
    rclpy.init()
    node = JointToUart()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.ser.close()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

