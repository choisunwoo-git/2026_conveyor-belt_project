import time
import cv2
import numpy as np
import mediapipe as mp
import serial
from mediapipe.tasks import python as mp_tasks
from mediapipe.tasks.python import vision

MODEL_PATH = "/home/qntmxjv/PycharmProjects/RoadExtractionProject_3/models/hand_landmarker.task"

# ====== STM32 (색/STOP) ======
STM_PORT = "/dev/ttyACM0"   # ✅ 여기 중요: DC모터(STM) 잘 되던 포트로
STM_BAUD = 115200

# ====== ROBOT (A:... 송신) ======
ROBOT_PORT = "/dev/serial/by-id/usb-Digilent_Digilent_USB_Device_210183BCBF19-if01-port0"
ROBOT_BAUD = 115200

ROBOT_PERIOD_SEC = 1.0          # 1초에 1번 유지 전송(1Hz)
ROBOT_OPEN_DELAY_SEC = 0.2      # 터미널 방식(포트 열고 0.2s 후 송신)

MIN_AREA = 800
STOP_REPEAT_SEC = 0.10          # 손 보이는 동안 S1 반복 전송
COLOR_COOLDOWN_SEC = 0.15       # 색상 변경 전송 쿨다운(깜빡임 방지)
COLOR_REPEAT_SEC = 0.25         # ✅ 색 ON(1) 유지 중에도 주기적으로 재전송(DC모터 유지용)

WIN = "webcam"


def find_largest_color_blob(hsv, lower, upper, min_area=MIN_AREA):
    mask = cv2.inRange(hsv, lower, upper)
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None, mask

    c = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(c)
    if area < min_area:
        return None, mask

    x, y, w, h = cv2.boundingRect(c)
    cx, cy = x + w // 2, y + h // 2
    return (x, y, w, h, cx, cy, area), mask


def send_line(ser, s: str):
    if ser is None:
        return
    ser.write((s + "\n").encode("ascii"))
    ser.flush()


def maybe_send_color(ser, key_char, state, last_state, last_send_time,
                     cooldown=COLOR_COOLDOWN_SEC, repeat_sec=COLOR_REPEAT_SEC):
    """
    ✅ 핵심:
    - state==1(ON)일 때는 repeat_sec마다 같은 명령을 재전송해서
      STM32쪽 DC모터가 '유지'되도록 함.
    - state==0(OFF)은 상태 바뀔 때만 전송.
    """
    now = time.time()

    if state == 1:
        # ON 진입(변화) or ON 유지(주기 재전송)
        if (state != last_state and (now - last_send_time) >= cooldown) or ((now - last_send_time) >= repeat_sec):
            send_line(ser, f"{key_char}1")
            return 1, now
        return 1, last_send_time

    # OFF는 변화 있을 때만
    if state != last_state and (now - last_send_time) >= cooldown:
        send_line(ser, f"{key_char}0")
        return 0, now

    return 0, last_send_time


# ===== 로봇(A:...) 유틸 =====
def clamp(v, lo=0, hi=180):
    return max(lo, min(hi, int(v)))


def format_robot_cmd(values6):
    vals = [clamp(v) for v in values6]
    return "A:" + ",".join(f"{v:03d}" for v in vals)


def send_robot_cmd_open_each_time(cmd_line: str):
    """터미널에서 성공한 방식과 동일: 포트 열고 0.2s 대기 후 송신"""
    with serial.Serial(
        ROBOT_PORT, ROBOT_BAUD, timeout=0.1,
        rtscts=False, dsrdtr=False, xonxoff=False
    ) as s:
        try:
            s.dtr = True
            s.rts = False
        except Exception:
            pass

        time.sleep(ROBOT_OPEN_DELAY_SEC)
        s.write((cmd_line + "\n").encode("ascii"))
        s.flush()


def send_robot_pose(values6):
    cmd = format_robot_cmd(values6)
    send_robot_cmd_open_each_time(cmd)


def main():
    # ===== 카메라 =====
    cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
    if not cap.isOpened():
        raise RuntimeError("웹캠 열기 실패")

    # ===== STM 시리얼 (DC모터) =====
    ser_stm = None
    try:
        ser_stm = serial.Serial(STM_PORT, STM_BAUD, timeout=0.05)
        time.sleep(2.0)
        print(f"[INFO] STM OPEN OK: {STM_PORT} @ {STM_BAUD}")
    except Exception as e:
        print(f"[ERROR] STM open failed: {e}")
        print("[ERROR] STM(DC모터) 포트가 열리지 않아서 DC모터는 동작하지 않습니다.")
        # DC모터가 목적이면 여기서 종료하는 게 맞음
        raise

    # ===== 로봇 포트 체크 =====
    try:
        with serial.Serial(ROBOT_PORT, ROBOT_BAUD, timeout=0.1) as _t:
            pass
        print(f"[INFO] ROBOT PORT OK: {ROBOT_PORT} @ {ROBOT_BAUD}")
    except Exception as e:
        raise RuntimeError(f"ROBOT_PORT open failed: {e}")

    # ===== OpenCV 전체화면 =====
    cv2.namedWindow(WIN, cv2.WINDOW_NORMAL)
    cv2.setWindowProperty(WIN, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    # ===== MediaPipe =====
    base_options = mp_tasks.BaseOptions(model_asset_path=MODEL_PATH)
    options = vision.HandLandmarkerOptions(
        base_options=base_options,
        running_mode=vision.RunningMode.VIDEO,
        num_hands=1,
        min_hand_detection_confidence=0.6,
        min_hand_presence_confidence=0.6,
        min_tracking_confidence=0.6,
    )

    # ===== HSV 범위 =====
    red1_lower = np.array([0, 120, 70]);   red1_upper = np.array([10, 255, 255])
    red2_lower = np.array([170, 120, 70]); red2_upper = np.array([180, 255, 255])
    blue_lower = np.array([100, 150, 50]); blue_upper = np.array([130, 255, 255])
    yellow_lower = np.array([20, 120, 70]); yellow_upper = np.array([35, 255, 255])

    # ===== STM 색 상태 =====
    last_r = last_b = last_y = 0
    last_r_t = last_b_t = last_y_t = 0.0

    prev_hand = 0
    last_stop_t = 0.0

    # ===== 로봇 1Hz 송신 타이머 =====
    last_robot_send = 0.0
    last_robot_pose = None

    # ===== 로봇 기본 포즈 =====
    POSE_NEUTRAL = [90, 26, 0, 0, 90, 0]
    POSE_STOP    = [90, 26, 0, 0, 90, 0]

    # (fallback용) 고정 포즈
    POSE_BLUE    = [63, 114, 38, 26, 90, 13]
    POSE_YELLOW  = [63, 114, 38, 26, 90, 51]

    # ===== ✅ 색별 시퀀스 =====
    RED_SEQ = [
        ([63,  91, 29, 26, 90,  0], 11.0),
        ([63, 114, 38, 26, 90,  0], 6.0),
        ([63, 114, 38, 26, 90, 51], 6.0),
        ([63,  97, 38, 26, 90, 51], 6.0),

        ([141,  97, 38, 26, 90, 51], 8.0),
        ([141, 108, 38, 26, 90, 51], 8.0),
        ([141, 108, 38, 26, 90,  0], 8.0),
        ([141,  97, 38, 26, 90,  0], 8.0),
    ]

    BLUE_SEQ = [
        ([63,  91, 29, 26, 90,  0], 11.0),
        ([63, 114, 38, 26, 90,  0], 6.0),
        ([63, 114, 38, 26, 90, 51], 6.0),
        ([63,  97, 38, 26, 90, 51], 6.0),

        ([120,  97, 38, 26, 90, 51], 8.0),
        ([120, 108, 38, 26, 90, 51], 8.0),
        ([120, 108, 38, 26, 90,  0], 8.0),
        ([120,  97, 38, 26, 90,  0], 8.0),
    ]

    YELLOW_SEQ = [
        ([63,  91, 29, 26, 90,  0], 11.0),
        ([63, 114, 38, 26, 90,  0], 6.0),
        ([63, 114, 38, 26, 90, 51], 6.0),
        ([63,  97, 38, 26, 90, 51], 6.0),

        ([ 92,  97, 38, 26, 90, 51], 8.0),
        ([ 92, 108, 38, 26, 90, 51], 8.0),
        ([ 92, 108, 38, 26, 90,  0], 8.0),
        ([ 92,  97, 38, 26, 90,  0], 8.0),
    ]

    SEQ_MAP = {"R": RED_SEQ, "B": BLUE_SEQ, "Y": YELLOW_SEQ}

    # ===== 시퀀스 상태 (현재 1개만 실행) =====
    seq_active = False
    seq_idx = 0
    seq_step_start = 0.0
    active_color = None
    active_seq = None

    # 색별 armed/hold
    armed = {"R": True, "B": True, "Y": True}
    hold_after = {"R": False, "B": False, "Y": False}
    hold_pose = {"R": None, "B": None, "Y": None}

    with vision.HandLandmarker.create_from_options(options) as landmarker:
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            frame = cv2.flip(frame, 1)

            # ---- 손 감지 ----
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
            ts = int(time.time() * 1000)
            result = landmarker.detect_for_video(mp_image, ts)

            h, w, _ = frame.shape
            hand_present = 1 if result.hand_landmarks else 0

            if result.hand_landmarks:
                for hand_landmarks in result.hand_landmarks:
                    for lm in hand_landmarks:
                        x, y = int(lm.x * w), int(lm.y * h)
                        cv2.circle(frame, (x, y), 4, (0, 255, 0), -1)

            now = time.time()

            red_blob = blue_blob = yellow_blob = None
            r_state = b_state = y_state = 0

            # =========================
            # 손 보이면: S1 반복 + 시퀀스/홀드 즉시 취소
            # =========================
            if hand_present:
                if prev_hand == 0:
                    send_line(ser_stm, "S1")
                    last_stop_t = now
                    last_r = last_b = last_y = 0
                    last_r_t = last_b_t = last_y_t = now

                if (now - last_stop_t) >= STOP_REPEAT_SEC:
                    send_line(ser_stm, "S1")
                    last_stop_t = now

                prev_hand = 1

                # 모든 상태 리셋
                seq_active = False
                seq_idx = 0
                seq_step_start = 0.0
                active_color = None
                active_seq = None
                for c in ("R", "B", "Y"):
                    armed[c] = True
                    hold_after[c] = False
                    hold_pose[c] = None

            # =========================
            # 손 없으면: S0 1회 + 색 인식/전송
            # =========================
            else:
                if prev_hand == 1:
                    send_line(ser_stm, "S0")
                prev_hand = 0
                last_stop_t = 0.0

                hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

                r1, _ = find_largest_color_blob(hsv, red1_lower, red1_upper)
                r2, _ = find_largest_color_blob(hsv, red2_lower, red2_upper)
                if r1 and r2:
                    red_blob = r1 if r1[-1] >= r2[-1] else r2
                else:
                    red_blob = r1 or r2

                blue_blob, _ = find_largest_color_blob(hsv, blue_lower, blue_upper)
                yellow_blob, _ = find_largest_color_blob(hsv, yellow_lower, yellow_upper)

                r_state = 1 if red_blob else 0
                b_state = 1 if blue_blob else 0
                y_state = 1 if yellow_blob else 0

                last_r, last_r_t = maybe_send_color(ser_stm, "R", r_state, last_r, last_r_t)
                last_b, last_b_t = maybe_send_color(ser_stm, "B", b_state, last_b, last_b_t)
                last_y, last_y_t = maybe_send_color(ser_stm, "Y", y_state, last_y, last_y_t)

            # =========================
            # 로봇 제어: R/B/Y 시퀀스 + hold
            # =========================
            desired_pose = POSE_NEUTRAL

            if hand_present:
                desired_pose = POSE_STOP
            else:
                # 색 사라지면 재무장 + 홀드 해제
                if r_state == 0:
                    armed["R"] = True; hold_after["R"] = False; hold_pose["R"] = None
                if b_state == 0:
                    armed["B"] = True; hold_after["B"] = False; hold_pose["B"] = None
                if y_state == 0:
                    armed["Y"] = True; hold_after["Y"] = False; hold_pose["Y"] = None

                # 현재 보이는 색 우선순위(R>B>Y)
                target = None
                if r_state: target = "R"
                elif b_state: target = "B"
                elif y_state: target = "Y"

                # 1) 시퀀스 시작
                if (target is not None) and armed[target] and (not seq_active) and (not hold_after[target]):
                    seq_active = True
                    active_color = target
                    active_seq = SEQ_MAP[target]
                    seq_idx = 0
                    seq_step_start = now
                    armed[target] = False

                    pose0, _ = active_seq[0]
                    send_robot_pose(pose0)
                    last_robot_send = now
                    last_robot_pose = pose0

                # 2) 시퀀스 진행
                if seq_active and (active_seq is not None):
                    pose, dur = active_seq[seq_idx]
                    if (now - seq_step_start) >= dur:
                        seq_idx += 1
                        if seq_idx >= len(active_seq):
                            lastp = active_seq[-1][0]
                            hold_after[active_color] = True
                            hold_pose[active_color] = lastp

                            seq_active = False
                            seq_idx = 0
                            seq_step_start = 0.0
                            active_seq = None
                            active_color = None

                            desired_pose = lastp
                        else:
                            seq_step_start = now
                            pose, dur = active_seq[seq_idx]
                            send_robot_pose(pose)
                            last_robot_send = now
                            last_robot_pose = pose
                            desired_pose = pose
                    else:
                        desired_pose = pose

                # 3) 홀드(색 유지 중이면 마지막 포즈 유지)
                elif (target is not None) and hold_after[target] and (hold_pose[target] is not None):
                    desired_pose = hold_pose[target]

                # 4) 기본/fallback
                else:
                    if target == "B":
                        desired_pose = POSE_BLUE
                    elif target == "Y":
                        desired_pose = POSE_YELLOW
                    else:
                        desired_pose = POSE_NEUTRAL

            # 1초에 1번 유지 전송
            if (now - last_robot_send) >= ROBOT_PERIOD_SEC:
                send_robot_pose(desired_pose)
                last_robot_send = now
                last_robot_pose = desired_pose

            # ---- 박스 표시 ----
            if not hand_present:
                if red_blob:
                    x, y, bw, bh, cx, cy, area = red_blob
                    cv2.rectangle(frame, (x, y), (x + bw, y + bh), (0, 0, 255), 2)
                    cv2.putText(frame, f"RED {int(area)}", (x, y - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
                if blue_blob:
                    x, y, bw, bh, cx, cy, area = blue_blob
                    cv2.rectangle(frame, (x, y), (x + bw, y + bh), (255, 0, 0), 2)
                    cv2.putText(frame, f"BLUE {int(area)}", (x, y - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
                if yellow_blob:
                    x, y, bw, bh, cx, cy, area = yellow_blob
                    cv2.rectangle(frame, (x, y), (x + bw, y + bh), (0, 255, 255), 2)
                    cv2.putText(frame, f"YELLOW {int(area)}", (x, y - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)

            # 상태 표시
            cv2.putText(frame, f"HAND:{hand_present}", (20, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
            cv2.putText(frame, f"R:{r_state} B:{b_state} Y:{y_state}", (20, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)

            # 시퀀스 텍스트
            if seq_active and active_color is not None and active_seq is not None:
                seq_txt = f"{active_color}_SEQ {seq_idx+1}/{len(active_seq)}"
            else:
                hold_list = [c for c in ("R", "B", "Y") if hold_after[c]]
                seq_txt = f"HOLD({','.join(hold_list)})" if hold_list else "IDLE"
            cv2.putText(frame, f"SEQ:{seq_txt}", (20, 90),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

            if last_robot_pose is not None:
                cv2.putText(frame, f"ROBOT:{format_robot_cmd(last_robot_pose)}", (20, 120),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)

            cv2.imshow(WIN, frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            elif key == ord("f"):
                prop = cv2.getWindowProperty(WIN, cv2.WND_PROP_FULLSCREEN)
                cv2.setWindowProperty(
                    WIN, cv2.WND_PROP_FULLSCREEN,
                    cv2.WINDOW_NORMAL if prop == cv2.WND_PROP_FULLSCREEN else cv2.WINDOW_FULLSCREEN
                )

    cap.release()
    if ser_stm is not None:
        ser_stm.close()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
