/* USER CODE BEGIN Header */
/*
 * MCP2515 + STM32 HAL  (TX/RX 통합 완성본 + TX 버튼으로 0x103 송신)
 *
 * PC(UART) -> STM32(TX 노드) -> CAN -> STM32(RX 노드) -> DC Motor
 *
 * PC sends (python):
 *   R1 / R0 / B1 / B0 / Y1 / Y0
 *   (optional) "R1 180" to set speed
 *   S1 / S0   (손 감지: 즉각 정지 / 손 사라짐: 정지 해제)
 *
 * 추가:
 *   TX 보드의 버튼(PC1)을 누르면 CAN_CMD_ID(0x103) 프레임을 송신
 *   RX 보드는 0x103도 Motor_Set으로 처리
 *
 * - NODE_IS_TRANSMITTER = 1 : UART 명령 + 버튼 -> CAN 송신
 * - NODE_IS_TRANSMITTER = 0 : CAN 수신 -> 모터 제어
 *
 * RX 노드에는 stop_latch가 있어서 STOP(S1)가 오면 즉각 모터 OFF + 이후 색/버튼 명령 무시
 * S0가 오면 stop_latch 해제 후 다시 명령 반영
 */
/* USER CODE END Header */

#include "main.h"
#include "gpio.h"
#include "spi.h"
#include "usart.h"

#include <stdio.h>
#include <string.h>

#include "mcp2515.h"
#include "can.h"

/* ====== 역할 설정 ====== */
#define NODE_IS_TRANSMITTER   1   // ✅ TX 보드=1, RX 보드=0 로 각각 빌드/업로드

/* ====== CAN 설정 ====== */
#define CAN_ID_RED            0x100
#define CAN_ID_BLUE           0x101
#define CAN_ID_YELLOW         0x102
#define CAN_CMD_ID            0x103   // ✅ 버튼 전용(추가 명령)
#define CAN_ID_STOP           0x1FF   // ✅ STOP 전용 ID

/* ====== UART 설정 ====== */
#define UART_TIMEOUT_MS       100
extern UART_HandleTypeDef huart2;

/* ====== 버튼 핀 (TX 보드에 달린 버튼) ======
 * ⚠️ CubeMX에서 PC1을 Input으로 설정 + Pull-up 권장
 * Pull-up이면: 평소 1, 누르면 0
 */
#define BTN_GPIO_Port         GPIOC
#define BTN_Pin               GPIO_PIN_13
#define BTN_DEBOUNCE_MS       20

/* ====== 모터 핀(RX 보드) ====== */
#define MOTOR_PORT            GPIOA
#define MOTOR_IN1_Pin         GPIO_PIN_11
#define MOTOR_IN2_Pin         GPIO_PIN_12

/* ====== UART 로그 ====== */
static void uart_log(const char *s)
{
  HAL_UART_Transmit(&huart2, (uint8_t*)s, (uint16_t)strlen(s), UART_TIMEOUT_MS);
}

/* (선택) printf 리다이렉트 */
int _write(int file, char *ptr, int len)
{
  (void)file;
  HAL_UART_Transmit(&huart2, (uint8_t*)ptr, (uint16_t)len, UART_TIMEOUT_MS);
  return len;
}

/* ====== CAN 송신 ====== */
static void send_motor_cmd(uint32_t id, uint8_t onoff, uint8_t speed)
{
  can_frame tx;
  memset(&tx, 0, sizeof(tx));

  tx.can_id  = id;
  tx.can_dlc = 2;
  tx.data[0] = onoff;
  tx.data[1] = speed;

  CAN_Error e = MCP_sendMessage(&tx);

  char buf[120];
  snprintf(buf, sizeof(buf),
           "[TX] ID=%lu onoff=%u speed=%u err=%d\r\n",
           (unsigned long)id, onoff, speed, (int)e);
  uart_log(buf);
}

/* ====== STOP 송신 ====== */
static void send_stop_cmd(uint8_t stop_on)
{
  can_frame tx;
  memset(&tx, 0, sizeof(tx));

  tx.can_id  = CAN_ID_STOP;
  tx.can_dlc = 2;
  tx.data[0] = stop_on ? 1 : 0;
  tx.data[1] = 0;

  CAN_Error e = MCP_sendMessage(&tx);

  char buf[120];
  snprintf(buf, sizeof(buf),
           "[TX] STOP=%u ID=%lu err=%d\r\n",
           stop_on ? 1 : 0, (unsigned long)CAN_ID_STOP, (int)e);
  uart_log(buf);
}

/* ====== 모터 제어(RX) ====== */
static void Motor_Set(uint8_t onoff, uint8_t speed)
{
  (void)speed; // PWM 쓰려면 여기서 speed로 PWM 듀티 조절

  if (onoff)
  {
    HAL_GPIO_WritePin(MOTOR_PORT, MOTOR_IN1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(MOTOR_PORT, MOTOR_IN2_Pin, GPIO_PIN_RESET);
    uart_log("[MOTOR] ON\r\n");
  }
  else
  {
    HAL_GPIO_WritePin(MOTOR_PORT, MOTOR_IN1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(MOTOR_PORT, MOTOR_IN2_Pin, GPIO_PIN_RESET);
    uart_log("[MOTOR] OFF\r\n");
  }
}

/* ====== CAN 수신 처리(RX) ====== */
#if !NODE_IS_TRANSMITTER
static uint8_t stop_latch = 0;   // ✅ STOP 유지(우선권)
#endif

static void process_can_rx(void)
{
  if (!MCP_checkReceive()) return;

  can_frame rx;
  CAN_Error e = MCP_readMessage(&rx);
  if (e != ERROR_OK) return;

  uint32_t id = (rx.can_id & CAN_SFF_MASK);

  /* ---- RX 로그 ---- */
  {
    char buf[128];
    int n = snprintf(buf, sizeof(buf),
                     "[RX] ID=%lu DLC=%u DATA=",
                     (unsigned long)id, rx.can_dlc);
    HAL_UART_Transmit(&huart2, (uint8_t*)buf, (uint16_t)n, UART_TIMEOUT_MS);

    for (uint8_t i = 0; i < rx.can_dlc; i++)
    {
      char b2[12];
      int m = snprintf(b2, sizeof(b2), "%u ", rx.data[i]);
      HAL_UART_Transmit(&huart2, (uint8_t*)b2, (uint16_t)m, UART_TIMEOUT_MS);
    }
    uart_log("\r\n");
  }

#if !NODE_IS_TRANSMITTER
  /* ✅ STOP 프레임 최우선 처리 */
  if (id == CAN_ID_STOP && rx.can_dlc >= 1)
  {
    uint8_t stop_on = (rx.data[0] != 0);
    stop_latch = stop_on;

    if (stop_on)
    {
      Motor_Set(0, 0); // 즉각 OFF
      uart_log("[STOP] LATCH ON -> MOTOR OFF\r\n");
    }
    else
    {
      uart_log("[STOP] LATCH OFF\r\n");
    }
    return;
  }

  /* ✅ STOP 유지 중이면 나머지(색/버튼) 명령 무시 */
  if (stop_latch)
  {
    uart_log("[RX] ignored (STOP latched)\r\n");
    return;
  }
#endif

  /* ✅ 모터 명령 처리: R/B/Y + 버튼(0x103)까지 모두 Motor_Set */
  if (rx.can_dlc >= 2)
  {
    if (id == CAN_ID_RED || id == CAN_ID_BLUE || id == CAN_ID_YELLOW || id == CAN_CMD_ID)
    {
      Motor_Set(rx.data[0], rx.data[1]);
    }
  }
}

/* ====== MCP2515 초기화 ====== */
static uint8_t mcp2515_init(void)
{
  uart_log("MCP2515 init...\r\n");

  if (MCP_reset() != ERROR_OK)
  {
    uart_log("MCP_reset FAIL\r\n");
    return 0;
  }

  /* 네 모듈 기준 8MHz + 500kbps */
  if (MCP_setBitrateClock(CAN_500KBPS, MCP_8MHZ) != ERROR_OK)
  {
    uart_log("Bitrate set FAIL\r\n");
    return 0;
  }

  /* 필터/마스크: 전부 통과 */
  MCP_setFilterMask(MASK0, 0, 0x000);
  MCP_setFilterMask(MASK1, 0, 0x000);
  MCP_setFilter(RXF0, 0, 0x000);
  MCP_setFilter(RXF1, 0, 0x000);
  MCP_setFilter(RXF2, 0, 0x000);
  MCP_setFilter(RXF3, 0, 0x000);
  MCP_setFilter(RXF4, 0, 0x000);
  MCP_setFilter(RXF5, 0, 0x000);

  if (MCP_setNormalMode() != ERROR_OK)
  {
    uart_log("Normal mode FAIL\r\n");
    return 0;
  }

  uart_log("MCP2515 OK (Normal mode)\r\n");
  return 1;
}

/* ====== UART RX(PC->STM) : TX 노드에서 사용 ====== */
#if NODE_IS_TRANSMITTER
static uint8_t rx_ch;
static char cmd_buf[16];
static uint8_t cmd_idx = 0;

static uint8_t stop_active = 0; // ✅ TX 측 STOP 상태(색 명령 무시용)

static void start_uart_rx_it(void)
{
  HAL_UART_Receive_IT(&huart2, &rx_ch, 1);
}

/*
 * 명령:
 *  R1 / R0 / B1 / B0 / Y1 / Y0
 *  (옵션) R1 180  -> speed 설정
 *  S1 / S0        -> STOP latch on/off (CAN_ID_STOP로 송신)
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance != USART2) return;

  if (rx_ch == '\n' || rx_ch == '\r')
  {
    cmd_buf[cmd_idx] = 0;

    char c = cmd_buf[0];   // 'R' 'B' 'Y' 'S'
    int onoff = -1;
    int speed = 180;

    if (c == 'S')
    {
      sscanf(cmd_buf + 1, "%d", &onoff);
      onoff = (onoff > 0) ? 1 : 0;

      stop_active = (uint8_t)onoff;
      send_stop_cmd(stop_active);
    }
    else if (c == 'R' || c == 'B' || c == 'Y')
    {
      if (stop_active)
      {
        uart_log("[TX] ignored color cmd (STOP active)\r\n");
      }
      else
      {
        sscanf(cmd_buf + 1, "%d %d", &onoff, &speed);

        if (onoff < 0) onoff = 0;
        if (onoff > 1) onoff = 1;
        if (speed < 0) speed = 0;
        if (speed > 255) speed = 255;

        uint32_t id = CAN_ID_RED;
        if (c == 'B') id = CAN_ID_BLUE;
        if (c == 'Y') id = CAN_ID_YELLOW;

        send_motor_cmd(id, (uint8_t)onoff, (uint8_t)speed);
      }
    }

    cmd_idx = 0;
  }
  else
  {
    if (cmd_idx < sizeof(cmd_buf) - 1)
      cmd_buf[cmd_idx++] = (char)rx_ch;
  }

  HAL_UART_Receive_IT(&huart2, &rx_ch, 1);
}
#endif

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void Error_Handler(void);

/* ====== main ====== */
int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_SPI2_Init();
  MX_USART2_UART_Init();

  uart_log("\r\nUART OK\r\n");

#if NODE_IS_TRANSMITTER
  uart_log("--- START: TX(UART+BTN -> CAN) ---\r\n");
  start_uart_rx_it();
  uart_log("UART RX START\r\n");
#else
  uart_log("--- START: RX(CAN->MOTOR) ---\r\n");
#endif

  uart_log("BEFORE MCP\r\n");
  uint8_t mcp_ok = mcp2515_init();
  uart_log("AFTER MCP\r\n");

  if (!mcp_ok)
  {
    uart_log("WARNING: MCP init failed. (Check CS pin + wiring)\r\n");
  }

#if NODE_IS_TRANSMITTER
  /* ✅ TX 버튼 상태 기억(디바운스 포함) */
  uint8_t last_pressed = 0xFF;
#endif

  while (1)
  {
#if NODE_IS_TRANSMITTER
    /* ===== 버튼 -> 0x103 송신 ===== */
    GPIO_PinState raw = HAL_GPIO_ReadPin(BTN_GPIO_Port, BTN_Pin);

    /* Pull-up 기준: 평소 1, 누르면 0 -> 눌림을 1로 통일 */
    uint8_t pressed = (raw == GPIO_PIN_RESET) ? 1 : 0;

    if (pressed != last_pressed)
    {
      /* 디바운스 */
      HAL_Delay(BTN_DEBOUNCE_MS);

      raw = HAL_GPIO_ReadPin(BTN_GPIO_Port, BTN_Pin);
      uint8_t pressed2 = (raw == GPIO_PIN_RESET) ? 1 : 0;

      if (pressed2 == pressed)
      {
        last_pressed = pressed;

        /* STOP 활성이어도 보내는 건 상관없음(RX가 latch면 무시함)
           원하면 stop_active일 때는 아예 안 보내도록 if(stop_active) return; 넣어도 됨 */
        send_motor_cmd(CAN_CMD_ID, pressed, 180);
        uart_log(pressed ? "[BTN] 0x103 ON\r\n" : "[BTN] 0x103 OFF\r\n");
      }
    }

    /* UART 명령은 인터럽트 콜백에서 처리됨 */

#else
    process_can_rx();
#endif

    HAL_Delay(1);
  }
}

/* ⚠️ SystemClock_Config는 CubeMX 생성본 쓰는게 제일 안전 */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;

  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;   // 84MHz
  RCC_OscInitStruct.PLL.PLLQ = 7;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;

  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif
