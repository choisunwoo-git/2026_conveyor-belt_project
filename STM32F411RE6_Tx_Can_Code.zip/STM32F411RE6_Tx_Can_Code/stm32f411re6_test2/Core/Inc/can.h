#ifndef APP_CAN_H
#define APP_CAN_H

#include <stdint.h>

#define CAN_MAX_DLEN  8U

#define CAN_EFF_FLAG  0x80000000U
#define CAN_RTR_FLAG  0x40000000U

#define CAN_SFF_MASK  0x000007FFU
#define CAN_EFF_MASK  0x1FFFFFFFU

typedef struct {
    uint32_t can_id;
    uint8_t  can_dlc;
    uint8_t  data[8];
} can_frame;

#endif
