/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "mcp2515.h"        // CAN 함수 사용을 위해 추가
#include "can.h"            // can_frame 구조체 사용을 위해 추가

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
extern can_frame rx_frame;      // main.c의 변수 참조
extern uint8_t conveyor_busy;   // main.c의 변수 참조
uint8_t emergency_stop_flag = 0; // ✅ 전역 정지 플래그 추가
/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for CAN_RxTask */
osThreadId_t CAN_RxTaskHandle;
const osThreadAttr_t CAN_RxTask_attributes = {
  .name = "CAN_RxTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for Conveyor_RED */
osThreadId_t Conveyor_REDHandle;
const osThreadAttr_t Conveyor_RED_attributes = {
  .name = "Conveyor_RED",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};
/* Definitions for Conveyor_BLUE */
osThreadId_t Conveyor_BLUEHandle;
const osThreadAttr_t Conveyor_BLUE_attributes = {
  .name = "Conveyor_BLUE",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};
/* Definitions for Conveyor_YELLOW */
osThreadId_t Conveyor_YELLOWHandle;
const osThreadAttr_t Conveyor_YELLOW_attributes = {
  .name = "Conveyor_YELLOW",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};
/* Definitions for Conveyor_Task */
osThreadId_t Conveyor_TaskHandle;
const osThreadAttr_t Conveyor_Task_attributes = {
  .name = "Conveyor_Task",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};
/* Definitions for CAN_MsgQueue */
osMessageQueueId_t CAN_MsgQueueHandle;
const osMessageQueueAttr_t CAN_MsgQueue_attributes = {
  .name = "CAN_MsgQueue"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void StartCAN_RxTask(void *argument);
void StartConveyorRED(void *argument);
void StartConveyorBLUE(void *argument);
void StartConveyorYELLOW(void *argument);
void StartConveyorTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of CAN_MsgQueue */
  CAN_MsgQueueHandle = osMessageQueueNew (10, sizeof(uint32_t), &CAN_MsgQueue_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of CAN_RxTask */
  CAN_RxTaskHandle = osThreadNew(StartCAN_RxTask, NULL, &CAN_RxTask_attributes);

  /* creation of Conveyor_RED */
  Conveyor_REDHandle = osThreadNew(StartConveyorRED, NULL, &Conveyor_RED_attributes);

  /* creation of Conveyor_BLUE */
  Conveyor_BLUEHandle = osThreadNew(StartConveyorBLUE, NULL, &Conveyor_BLUE_attributes);

  /* creation of Conveyor_YELLOW */
  Conveyor_YELLOWHandle = osThreadNew(StartConveyorYELLOW, NULL, &Conveyor_YELLOW_attributes);

  /* creation of Conveyor_Task */
  Conveyor_TaskHandle = osThreadNew(StartConveyorTask, NULL, &Conveyor_Task_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_StartCAN_RxTask */
/**
* @brief Function implementing the CAN_RxTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartCAN_RxTask */
void StartCAN_RxTask(void *argument)
{
  /* USER CODE BEGIN StartCAN_RxTask */
	uint32_t received_id; // <--- 이 선언이 누락되었습니다!
  /* Infinite loop */
  for(;;)
  {
	  if (MCP_checkReceive()) {
	        if (MCP_readMessage(&rx_frame) == ERROR_OK) {
	          received_id = rx_frame.can_id & 0x7FF;

	          if (received_id == 0x1FF) {
	            emergency_stop_flag = 1; // ✅ 정지 신호 오면 플래그 ON
	          } else {
	            emergency_stop_flag = 0; // 일반 명령 오면 플래그 OFF (해제)
	            osMessageQueuePut(CAN_MsgQueueHandle, &received_id, 0U, 0U);
	          }
	        }
	      }
	      osDelay(10);
	    }
  /* USER CODE END StartCAN_RxTask */
}

/* USER CODE BEGIN Header_StartConveyorRED */
/**
* @brief Function implementing the Conveyor_RED thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartConveyorRED */
void StartConveyorRED(void *argument)
{
  /* USER CODE BEGIN StartConveyorRED */
	uint32_t msg_id;
  /* Infinite loop */
  for(;;)
  {
	  if (osMessageQueueGet(CAN_MsgQueueHandle, &msg_id, NULL, osWaitForever) == osOK) {
	        if (msg_id == 0x100) {
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_SET);
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET);

	          for (int i = 0; i < 10000; i++) {
	            if (emergency_stop_flag == 1) break; // ✅ 전역 변수이므로 모든 태스크가 동시에 확인 가능!
	            osDelay(10);
	          }

	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_RESET);
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET);
	        }
	      }
	    }

  /* USER CODE END StartConveyorRED */
}

/* USER CODE BEGIN Header_StartConveyorBLUE */
/**
* @brief Function implementing the Conveyor_BLUE thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartConveyorBLUE */
void StartConveyorBLUE(void *argument)
{
  /* USER CODE BEGIN StartConveyorBLUE */
	uint32_t msg_id;
  /* Infinite loop */
  for(;;)
  {
	  if (osMessageQueueGet(CAN_MsgQueueHandle, &msg_id, NULL, osWaitForever) == osOK) {
	        if (msg_id == 0x101) {
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);

	          for (int i = 0; i < 10000; i++) {
	            if (emergency_stop_flag == 1) break; // ✅ 전역 변수이므로 모든 태스크가 동시에 확인 가능!
	            osDelay(10);
	          }

	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
	        }
	      }
	    }

  /* USER CODE END StartConveyorBLUE */
}

/* USER CODE BEGIN Header_StartConveyorYELLOW */
/**
* @brief Function implementing the Conveyor_YELLOW thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartConveyorYELLOW */
void StartConveyorYELLOW(void *argument)
{
  /* USER CODE BEGIN StartConveyorYELLOW */
	uint32_t msg_id;
  /* Infinite loop */
  for(;;)
  {
	  if (osMessageQueueGet(CAN_MsgQueueHandle, &msg_id, NULL, osWaitForever) == osOK) {
	        if (msg_id == 0x102) {
	          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET);
	          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);

	          for (int i = 0; i < 10000; i++) {
	            if (emergency_stop_flag == 1) break; // ✅ 전역 변수이므로 모든 태스크가 동시에 확인 가능!
	            osDelay(10);
	          }

	          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET);
	          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
	        }
	      }
	    }

  /* USER CODE END StartConveyorYELLOW */
}

/* USER CODE BEGIN Header_StartConveyorTask */
/**
* @brief Function implementing the ConveyorTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartConveyorTask */
void StartConveyorTask(void *argument)
{
  /* USER CODE BEGIN StartConveyorTask */
	uint32_t msg_id; // <--- 이 선언이 누락되었습니다!
  /* Infinite loop */
  for(;;)
  {
	  if (osMessageQueueGet(CAN_MsgQueueHandle, &msg_id, NULL, osWaitForever) == osOK) {
	        if (msg_id == 0x103) {
	          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
	          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);

	          for (int i = 0; i < 10; i++) {
	            if (emergency_stop_flag == 1) break; // ✅ 전역 변수이므로 모든 태스크가 동시에 확인 가능!
	            osDelay(10);
	          }

	          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
	          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);
	        }
	      }
	    }

  /* USER CODE END StartConveyorTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

